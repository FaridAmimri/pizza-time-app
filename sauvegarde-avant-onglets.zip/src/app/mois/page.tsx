"use client";

import { useEffect, useMemo, useState } from "react";
import { ecartCaisse, recapMois, totalEnCaisse } from "@/domain/calculs";
import type { Fiche } from "@/domain/types";
import { dateFr, eur, formatHeures } from "@/lib/format";

export default function PageMois() {
  const [mois, setMois] = useState(() => new Date().toISOString().slice(0, 7));
  const [fiches, setFiches] = useState<Fiche[]>([]);

  useEffect(() => {
    fetch(`/api/fiches?mois=${mois}`).then((r) => r.json()).then(setFiches);
  }, [mois]);

  const recap = useMemo(() => recapMois(fiches), [fiches]);
  const r = recap.recettes;

  async function supprimer(date: string) {
    if (!confirm(`Supprimer la fiche du ${dateFr(date)} ?`)) return;
    await fetch(`/api/fiches?date=${date}`, { method: "DELETE" });
    setFiches((l) => l.filter((f) => f.date !== date));
  }

  return (
    <>
      <h1>Bilan du mois</h1>
      <div className="selecteur-mois">
        <div className="champ">
          <label htmlFor="mois">Mois</label>
          <input id="mois" type="month" value={mois} onChange={(e) => e.target.value && setMois(e.target.value)} />
        </div>
        {recap.nbFiches > 0 && (
          <a className="bouton secondaire" href={`/api/export?mois=${mois}`}>Télécharger pour Excel</a>
        )}
      </div>

      {recap.nbFiches === 0 ? (
        <p className="vide">Aucune fiche enregistrée pour ce mois. Scannez une fiche pour commencer.</p>
      ) : (
        <>
          <section className="bloc">
            <h2>Heures par employé</h2>
            <div className="defilement">
              <table className="tableau">
                <thead>
                  <tr><th>Employé</th><th className="nombre">Jours</th><th className="nombre">Matin</th><th className="nombre">Soir</th><th className="nombre">Total</th><th className="nombre">Acomptes</th></tr>
                </thead>
                <tbody>
                  {recap.employes.map((e) => (
                    <tr key={e.nom}>
                      <td>{e.nom}</td>
                      <td className="nombre">{e.jours}</td>
                      <td className="nombre">{formatHeures(e.matin)}</td>
                      <td className="nombre">{formatHeures(e.soir)}</td>
                      <td className="nombre"><strong>{formatHeures(e.journee)}</strong></td>
                      <td className="nombre">{eur(e.acomptes)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </section>

          <section className="bloc">
            <h2>Recettes</h2>
            <table className="tableau">
              <tbody>
                <tr><td>Espèces</td><td className="nombre">{eur(r.especes)}</td></tr>
                <tr><td>Tickets restaurant</td><td className="nombre">{eur(r.ticketRestaurant)}</td></tr>
                <tr><td>Cartes bancaires</td><td className="nombre">{eur(r.carteBancaire)}</td></tr>
                <tr><td>Chèques vacances</td><td className="nombre">{eur(r.chequeVacance)}</td></tr>
                <tr><td>Dishop en ligne</td><td className="nombre">{eur(r.dishopEnLigne)}</td></tr>
                <tr><td>Achats</td><td className="nombre">{eur(r.achats)}</td></tr>
                <tr><td>Acomptes</td><td className="nombre">{eur(r.acomptes)}</td></tr>
                <tr className="total"><td>Total en caisse</td><td className="nombre">{eur(r.totalEnCaisse)}</td></tr>
                <tr><td>Total en bon</td><td className="nombre">{eur(r.totalEnBon)}</td></tr>
              </tbody>
            </table>
          </section>

          <section className="bloc">
            <h2>Commandes internet</h2>
            <table className="tableau">
              <thead><tr><th>Plateforme</th><th className="nombre">Commandes</th><th className="nombre">Total</th></tr></thead>
              <tbody>
                {Object.entries(recap.plateformes).map(([nom, p]) => (
                  <tr key={nom}><td>{nom}</td><td className="nombre">{p.nbCommandes}</td><td className="nombre">{eur(p.total)}</td></tr>
                ))}
              </tbody>
            </table>
          </section>

          <section className="bloc">
            <h2>Fiches du mois ({recap.nbFiches})</h2>
            <div className="defilement">
              <table className="tableau">
                <thead><tr><th>Date</th><th className="nombre">Total en caisse</th><th>Contrôle</th><th></th></tr></thead>
                <tbody>
                  {fiches.map((f) => {
                    const ecart = ecartCaisse(f);
                    return (
                      <tr key={f.date}>
                        <td>{dateFr(f.date)}</td>
                        <td className="nombre">{eur(totalEnCaisse(f))}</td>
                        <td>
                          {ecart === null ? "Pas de total écrit" : Math.abs(ecart) < 0.01 ? <span className="ok">Correspond</span> : <span className="ecart-ko">Écart {eur(ecart)}</span>}
                        </td>
                        <td><button className="lien" onClick={() => supprimer(f.date)}>Supprimer</button></td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </section>
        </>
      )}
    </>
  );
}
