import type { Metadata } from "next";
import Link from "next/link";
import { Barlow, Barlow_Condensed } from "next/font/google";
import "./globals.css";

const corps = Barlow({ subsets: ["latin"], weight: ["400", "500", "600"], variable: "--police-corps" });
const titres = Barlow_Condensed({ subsets: ["latin"], weight: ["600", "700"], variable: "--police-titres" });

export const metadata: Metadata = {
  title: "Fiches journalières",
  description: "Lecture des fiches journalières par photo et bilan du mois",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="fr" className={`${corps.variable} ${titres.variable}`}>
      <body>
        <header className="entete">
          <span className="entete-titre">Fiches journalières</span>
          <nav>
            <Link href="/">Scanner une fiche</Link>
            <Link href="/mois">Bilan du mois</Link>
          </nav>
        </header>
        <main className="page">{children}</main>
      </body>
    </html>
  );
}
