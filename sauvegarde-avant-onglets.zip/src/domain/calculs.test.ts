import { test } from "node:test";
import assert from "node:assert/strict";
import { dureeMinutes, ecartCaisse, heuresEmploye, recapMois, totalEnCaisse } from "./calculs";
import { ficheVide } from "./fiche-vide";

function ficheExemple() {
  const f = ficheVide("2026-08-29");
  f.matin = { totalEnBon: null, totalEnCaisse: 170, especes: 100, ticketRestaurant: 20, carteBancaire: 50 };
  f.soir = { especes: 200, ticketRestaurant: 30, carteBancaire: 150, chequeVacance: 10, dishopEnLigne: 40 };
  f.achats = 15;
  f.totauxEcrits = { totalEnBon: 12, totalEnCaisse: 625 };
  f.employes = [
    { nom: "Sami", acompte: 20, matin: { da: "10:00", fs: "14:30" }, soir: { da: "18:00", fs: "00:30" } },
    { nom: "  sami ", acompte: null, matin: { da: "11:00", fs: "14:00" }, soir: { da: null, fs: null } },
    { nom: "Lina", acompte: null, matin: { da: "10:00", fs: null }, soir: { da: null, fs: null } },
  ];
  return f;
}

test("durée : passage de minuit", () => {
  assert.equal(dureeMinutes("18:00", "00:30"), 390);
  assert.equal(dureeMinutes("10:00", "14:30"), 270);
  assert.equal(dureeMinutes(null, "14:30"), 0);
});

test("heures d'un employé + détection d'oubli", () => {
  const f = ficheExemple();
  assert.deepEqual(heuresEmploye(f.employes[0]), { matin: 270, soir: 390, journee: 660, incomplet: false });
  assert.equal(heuresEmploye(f.employes[2]).incomplet, true);
});

test("total en caisse = espèces + tickets + CB + Dishop + acomptes + achats", () => {
  const f = ficheExemple();
  // 300 + 50 + 200 + 40 + 20 + 15 = 625
  assert.equal(totalEnCaisse(f), 625);
  assert.equal(ecartCaisse(f), 0);
  f.totauxEcrits.totalEnCaisse = 600;
  assert.equal(ecartCaisse(f), 25);
});

test("bilan du mois : regroupe un même employé écrit différemment", () => {
  const r = recapMois([ficheExemple(), ficheExemple()]);
  assert.equal(r.nbFiches, 2);
  assert.equal(r.recettes.totalEnCaisse, 1250);
  const sami = r.employes.find((e) => e.nom === "Sami");
  assert.equal(sami?.journee, 2 * (660 + 180));
  assert.equal(sami?.acomptes, 40);
  assert.equal(r.employes.length, 2);
});
