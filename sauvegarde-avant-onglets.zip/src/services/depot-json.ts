/** Stockage prototype : un fichier JSON dans ./data (une fiche par jour, un seul restaurant). */
import { promises as fs } from "fs";
import path from "path";
import type { Fiche } from "@/domain/types";
import type { DepotFiches } from "./depot";

const DOSSIER = path.join(process.cwd(), "data");
const FICHIER = path.join(DOSSIER, "fiches.json");
const PHOTOS = path.join(DOSSIER, "photos");

async function lireTout(): Promise<Record<string, Fiche>> {
  try {
    return JSON.parse(await fs.readFile(FICHIER, "utf-8"));
  } catch (e) {
    if ((e as NodeJS.ErrnoException).code === "ENOENT") return {};
    throw e;
  }
}

async function ecrireTout(data: Record<string, Fiche>) {
  await fs.mkdir(DOSSIER, { recursive: true });
  await fs.writeFile(FICHIER, JSON.stringify(data, null, 2), "utf-8");
}

export const depotJson: DepotFiches = {
  async lister(mois) {
    const toutes = Object.values(await lireTout());
    return toutes.filter((f) => !mois || f.date.startsWith(mois)).sort((a, b) => a.date.localeCompare(b.date));
  },
  async sauvegarder(fiche, photoJpeg) {
    const data = await lireTout();
    data[fiche.date] = fiche;
    await ecrireTout(data);
    if (photoJpeg) {
      await fs.mkdir(PHOTOS, { recursive: true });
      await fs.writeFile(path.join(PHOTOS, `${fiche.date}.jpg`), photoJpeg);
    }
  },
  async supprimer(date) {
    const data = await lireTout();
    delete data[date];
    await ecrireTout(data);
  },
};
