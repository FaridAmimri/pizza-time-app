/**
 * Point d'entrée unique du stockage. Le reste du code n'utilise que `depot`.
 * Pour passer à PostgreSQL : écrire depot-postgres.ts qui respecte DepotFiches,
 * puis changer la ligne `export const depot` ci-dessous. Rien d'autre à modifier.
 */
import type { Fiche } from "@/domain/types";
import { depotJson } from "./depot-json";

export interface DepotFiches {
  /** Fiches d'un mois ("2026-08"), triées par date. Sans argument : toutes. */
  lister(mois?: string): Promise<Fiche[]>;
  /** Crée ou remplace la fiche de ce jour. */
  sauvegarder(fiche: Fiche, photoJpeg?: Buffer): Promise<void>;
  supprimer(date: string): Promise<void>;
}

export const depot: DepotFiches = depotJson;
