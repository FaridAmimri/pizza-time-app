const euros = new Intl.NumberFormat("fr-FR", { style: "currency", currency: "EUR" });

export const eur = (v: number): string => euros.format(v);

export function formatHeures(minutes: number): string {
  const h = Math.floor(minutes / 60);
  const m = minutes % 60;
  return m === 0 ? `${h} h` : `${h} h ${String(m).padStart(2, "0")}`;
}

export const dateFr = (iso: string): string => iso.split("-").reverse().join("/");
