# Fiches journalières Pizza Time : prototype

Photo d'une fiche → lecture par Claude → vérification à l'écran → enregistrement → bilan du mois (heures par employé, recettes) → export Excel.

## Démarrer

```bash
npm install
cp .env.example .env.local     # puis coller votre clé ANTHROPIC_API_KEY
npm run dev                    # http://localhost:3000
npm test                       # tests des calculs
```

Sur téléphone (même réseau) : ouvrir `http://<ip-de-votre-pc>:3000`. La caméra s'ouvre avec le bouton « Prendre une photo ».

## Où modifier quoi

| Je veux…                                            | Fichier                          |
|-----------------------------------------------------|----------------------------------|
| Ajouter / retirer un champ de la fiche              | `src/domain/types.ts`, puis `src/components/FicheForm.tsx` |
| Changer une formule de calcul                       | `src/domain/calculs.ts` (+ test dans `calculs.test.ts`) |
| Adapter la lecture si la fiche papier change        | `src/services/prompt.ts`         |
| Changer de modèle IA                                | variable `ANTHROPIC_MODEL`       |
| Passer à PostgreSQL                                 | écrire `src/services/depot-postgres.ts` (interface `DepotFiches`), changer 1 ligne dans `depot.ts` |
| Modifier le fichier Excel exporté                   | `src/services/export-csv.ts`     |
| Changer les couleurs / le style                     | `src/app/globals.css` (variables en haut) |

## Principes

- **L'IA lit, le code calcule.** Claude recopie seulement ce qui est écrit ; tous les totaux sont calculés dans `calculs.ts`.
- **Une seule définition des données** (`types.ts`) : elle sert à l'IA, à la validation et à TypeScript.
- **Toujours une étape de vérification humaine.** Les champs douteux sont en jaune ; un écart avec le total écrit sur la fiche est signalé en rouge.
- **Stockage isolé** derrière une interface : le JSON du prototype se remplace sans toucher au reste.

## Hypothèses à faire valider par le client

1. Formule du total en caisse, telle qu'imprimée en bas de la fiche : espèces + ticket restaurant + carte bancaire + Dishop en ligne + acomptes + achats (le chèque vacances n'y figure pas).
2. « Total en bon » : repris tel qu'écrit sur la fiche, non recalculé.
3. Les « commandes internet déjà réglées » sont informatives : elles ne s'ajoutent pas au total en caisse.
4. Une fiche par jour, un seul restaurant (clé = date).
5. Les heures qui passent minuit (18:00 → 00:30) sont gérées.

## Idées d'évolutions faciles

Plusieurs restaurants (ajouter `restaurantId` au schéma et à la clé du dépôt) · connexion par mot de passe · liste d'employés connus pour corriger les noms mal lus · scan de plusieurs fiches d'un coup · export PDF · tarif horaire et coût salarial.
